function getTeamData() {
    $.get('team.json', function(data) {
      var teamContent = '';
  
      // build the HTML for team members
      for (var i in data) {
        teamContent += '<h2>' + data[i].name + '</h2>' +
                       '<h5>' + data[i].position + '</h5>' +
                       '<p>' + data[i].bio + '</p>';
      }
  
      // hide the team content div and display the loading message
      $('#team').hide();
      $('#team').html('<h1>LOADING...</h1>');
      $('#team').fadeIn();
  
      // delay for 3 seconds before displaying the team content
      setTimeout(function() {
        $('#team').html(teamContent);
      }, 3000);
    })
    .fail(function() {
      $('#team').html('The content could not be retrieved');
    });
  }
  
  $(document).ready(function() {
    getTeamData();
  });